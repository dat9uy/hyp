# Review of 613747c (git diff b4f23b2 613747c)

Ran: `go vet ./...` clean; `go test ./internal/cli -run Prompt -count=1` ok. Probed with /tmp/hyp-review (script /tmp/rv.sh).

All five earlier findings are fixed, with one exception (F2).
- A symlinked cwd to the same store prints the same bytes as the physical path.
- A CRLF body's `\r` blank line is accepted. The output keeps the `\r\n` bytes of the block lines, and trailing `\r` lines are trimmed. A `" \r"` line is still refused (exit 1).
- The Goal-id check now covers the whole prompt.
- The --branch message no longer says "branch name has none".

## F1 (none: text defect) docs/replay-spec.md, §7.5 Constraints block
The patch adds "A line is empty when it holds no byte or only a carriage return; a line of spaces or a tab is non-empty." It leaves the old sentence at the end of the same paragraph: "A line is empty only when it holds no byte, so a line of spaces inside the block is a bad line." The two now disagree about a lone `\r`. The glossary and both skills already say "or a lone carriage return" or "non-empty". Fix: delete the old sentence or reword it to "no byte or only a carriage return".

## F2 (none: test defect) internal/cli/prompt_test.go, in TestPromptPrintsTheGoalsRunPrompt (the added loop before `t.Chdir(t.TempDir())`)
The "skipped-on-.git" finding is only rephrased. The exit-3 assertion still skips the whole test when any ancestor of the temp dir holds a `.git`. The skip sits inside the main test, so on such a machine the exit 0 and exit 1 assertions that follow it are skipped too. It is not a failing input: the test passes here and the exit-3 branch ran. Fix: move the exit-3 check into its own test, or fake `repoRoot` through an injectable stat.

## F3 (none: text defect) internal/cli/prompt.go:27
The doc comment now runs one line past the others after `; a lone carriage return, ... is empty`. It also says "A line is empty only when it holds no byte", then makes an exception in the same sentence. Re-wrap it and drop "only".

## F4 (none: test gap) internal/cli/prompt_test.go TestPromptSymlinkAndCRLF
The CRLF case only checks that the physical and symlink outputs match and that the output contains "in inv/t ". It never asserts that the block's `\r\n` bytes are printed byte for byte, and never asserts that a `" \r"` line is refused. Both behave correctly when probed. Without the assertions, a change that strips `\r` from block lines would pass the test while breaking line 1 ("byte for byte").

## Observations, not findings
- A symlink inside the repository that points to a store outside it (/tmp/rv/repo/inv/lnk -> /tmp/rv/ext/t) gives exit 3 whether reached through the link or the physical path. The result is consistent. It follows from resolving the physical path, and spec §7.5 does not say which path counts.
- `--branch` with U+200B (a format character, neither IsSpace nor IsControl) is accepted and printed. A U+00A0 is refused with exit 2. Harmless to line 1, but "one-line name" is only partly enforced.
