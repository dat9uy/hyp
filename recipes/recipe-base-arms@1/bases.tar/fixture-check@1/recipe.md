---
name: fixture-check
version: 1
format: 1
subject: Run every case of a cases file with every arm binary, each on a fresh copy of a fixture store, and print what each arm did (exit, appended, warned)
---

# fixture-check

A Standalone check for arms that are hyp binaries, one per rival's
prototype: `cases` extracts a fixture archive for every arm and case, runs
the case's hyp steps with that arm and prints one row per arm and case.
The arms are the subject: it runs only the binaries it is given, by
absolute path, never the `hyp` on PATH. Write the cases file and make the
fixture for your method, and keep both in the bundle or name their sha256
in the Experiment's body.

## Standalone

Run cases: ./cases.py
External: reads each arm binary it is given by absolute path

- `cases CASES FIXTURE NAME=/abs/path...` prints a header and one row per
  arm and case: `arm case exit appended warned`, for the last step that
  ran. `appended` is `y` when the bytes under `fixture/.tree/events`
  changed during that step, and `warned` is `y` when its stderr holds a
  line starting with `warn:`. A case whose last step exits 3 runs once
  more. Each step's stderr goes to `$HYP_OUT/<arm>/<case>.<n>.stderr`.
  It exits 2 on a bad argument, such as a relative arm path.

`known-answers/` holds four stub arms (one appends, one warns, one
refuses, one exits 3) on a two-case fixture, and a relative arm path.
