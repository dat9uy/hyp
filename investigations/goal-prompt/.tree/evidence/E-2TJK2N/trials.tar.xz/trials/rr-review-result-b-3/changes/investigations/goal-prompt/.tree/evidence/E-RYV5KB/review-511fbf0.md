Review of commit 511fbf0 (subagent reply, word for word).

I found no defect in the hyp prompt paragraph of the "Constraints block" bullet at `docs/replay-spec.md` §7.5, as rewritten in 511fbf0. I read the code and ran a few probes in `/tmp`. The probes covered `-h`, an unknown flag after `--`, no store, and a non-integer `--experiments`.

**Order of checks.** The order stated in the paragraph matches `cmdPrompt` in `internal/cli/prompt.go` and `parse` in `internal/cli/write.go`:
1. Flag parse errors give exit 2. These are the unknown flag and the non-integer value, and they happen first (`write.go:54`, `prompt.go:100`).
2. Exit 2 for not exactly one id (`prompt.go:104`), no `--actor` (`prompt.go:107`, `$HYP_ACTOR` is never read), an invalid actor name, `--experiments` below 1, `--pr` below 0, and a `--branch` with a space or control character (`prompt.go:117`).
3. `openReader` gives exit 3 when no store is found. `ErrNoStore` carries no kind, and `herr.KindOf` treats an error with no kind as Environment (`herr.go:48`). The probe printed `no .tree store found; run 'hyp init'` and exited 3.
4. `resolveRef` in `internal/cli/resolve.go` gives exit 2 for an unknown id and for an alias held by two nodes. The Goal-kind check gives exit 2 for an id that is not a Goal.
5. A missing or invalid block gives exit 1, naming each problem, with nothing on stdout, because output is only written at the end. This check comes before the symlink and repository work, so the "wherever the store sits" claim is true.
6. `EvalSymlinks` failure and "no repository holds the store" give exit 3.

The statements about line splitting and `\r` also match the code. Lines split on `\n`. A line is empty only when it holds no byte. A bare `\r` line inside the block is refused. Block lines print byte for byte, and `--branch`/`--pr` clauses follow the block. No owner answer is read.

**Omissions.** These are small text gaps and the code is correct in each case. Neither affects Goal lines #1-#5.
- **`-h` and `--help` (`write.go:47-52`, label none, text).** `hyp prompt -h` prints usage and exits 0. The paragraph lists no exit 0 for help. The probe confirmed it.
- **Unreadable log (`read.go:51-56`, label none, text).** Any untyped error from `store.Events` or `FindRoot` also exits 3, for example an unreadable `.tree/events` file. The paragraph says only "when no store is found". This is an environment problem, so exit 3 is correct and only the wording is narrower than the code.
