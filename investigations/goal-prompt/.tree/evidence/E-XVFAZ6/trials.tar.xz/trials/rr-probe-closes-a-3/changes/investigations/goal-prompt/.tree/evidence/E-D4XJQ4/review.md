# Fresh review of git diff b4f23b2 fe352a4 (general-purpose subagent, read-only, nothing run)

Given: the diff, the five code-bearing lines #1-#5 verbatim, the spec location and AGENTS.md. Not given: the runner's Results or conclusion.

- F1 (#1, low): a store directory that is a symlink into a repository but points outside any repository exits 3 after EvalSymlinks; the same store reached physically inside another repository prints another path. Follows the new spec sentence (physical directory); a policy gap, case never run.
- F2 (none): rel is printed unquoted; a store path with a space or newline is ambiguous. Only unusual paths.
- F3 (#3, none): hyp add goal does not warn on a body with no heading at all, while hyp prompt refuses it. Matches the spec and TestPromptRefusesAnInvalidConstraintsBlock.
- F4 (none): t.Skip in TestPromptPrintsTheGoalsRunPrompt sits after every other assertion of that test; only the exit-3 case is lost on a machine whose temp directory is under a .git.
- F5 (#3, low): the CRLF test does not cover a trailing lone CR line or a CR after a heading line. Reviewer read the code: block lines print byte for byte; empty line is "" or "\r"; trailing empties are trimmed first.
- Clean: #2, #4, #5.
