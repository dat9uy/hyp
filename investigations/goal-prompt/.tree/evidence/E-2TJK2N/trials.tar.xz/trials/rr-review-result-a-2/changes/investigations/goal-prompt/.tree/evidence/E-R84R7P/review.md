Two defects, one against line 1 and one in how the symlink fix behaves. I built `/tmp/hypx` from the commit and probed it in throwaway stores under `/tmp/p`. I changed no repository file.

**Findings**

1. **Line 1, CRLF is not byte for byte (internal/cli/prompt.go, `constraintsBlock`, the `TrimSuffix(l, "\r")` loop).**
   - Input: a Goal body `Builds.\r\nMay change: a.\r\nRead only: b.\r\nNever: c.\r\n`.
   - Output: the block lines print as `May change: a.`, `Read only: b.` and `Never: c.`, with the `\r` dropped. Line 1 says each block line is printed byte for byte. The replay-spec says "as written" and does not mention the stripping.
   - The new CRLF test asserts that no `\r` appears in stdout. That asserts the departure from line 1 rather than checking it.
   - A line ending in `\r\r` is stripped only once. I did not check what it prints.

2. **Line 1 (exit 3, wrong message), the symlink fix in internal/cli/prompt.go `cmdPrompt`.**
   - `EvalSymlinks(root)` is now what decides which repository holds the store. A store that lives inside a repository only by a symlink whose target is outside it now fails. It printed the prompt before the commit.
   - Input: `/tmp/p/repo/sub/t` is a symlink to `/tmp/p/out/t`, and `.git` is in `/tmp/p/repo`. Running `hyp prompt G --actor r` there exits 3.
   - Output: `no repository holds the store /tmp/p/repo/sub/t ...`. The message names the unresolved path, which sits under a repository, so it contradicts the user's view. The same thing happens from `/tmp/p/repo/lnk2`, a symlink to `sub/t`, which resolves to the same outside target.
   - No test covers a symlink that leaves the repository. The symlink test only checks that a link to the same store prints the same bytes.

**Checked and correct**
- A CRLF body is accepted and its blank `\r\n` lines count as empty.
- Line 3: the CRLF heading detection is shared with the `hyp add goal` warning, because both call `constraintsBlock`.
- Line 5: the test helper `wantNamesOnly` now checks the Goal id in all four places of the prompt and rejects any other `G-` id.
- The skeleton of the prompt is unchanged apart from the CRLF stripping. A symlinked store under the same repository gives the same bytes as its physical path.
- The skill and doc edits cite no ADR and no file under `docs/`, so they pass the AGENTS.md rule.
- Exit codes in the new skill text (2 for a bad argument, 3 for no repository) match the code.
- The outside-repository test now skips when a parent directory holds `.git`.
- I did not run `go test`, so line 7 (skillcheck and the skill validators) is unchecked.
