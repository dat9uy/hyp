# Handoff: next /goal prompt for G-D1CH1R

Source: /tmp/g113-evals/exit/P/skills/hyp-owner-answer/SKILL.md, section "End each turn" (last paragraph). No command was run.

## 1. Command

Run this in the tree's own directory:

```text
hyp prompt G-D1CH1R --actor claude-g1b-7 --branch feat/x --pr 9
```

Give the owner the output as it is.

## 2. If the command exits 3

The store is in no repository. Stop. Tell the owner. Do not retry with other flags.

## 3. If the command exits 1

The Goal body has no valid constraints block. Tell the owner. Do not edit the Goal body.

## 4. What to add about the owner's answers

Add nothing about the owner's answers to the prompt. Do not paste them in. OWED lists each answer and each returned limit that the next run applies.

## Notes

- Exit 2 means a bad flag. Fix the flag and run the command again. The skill names exit 2 but gives no further step, so this is only the general rule.
