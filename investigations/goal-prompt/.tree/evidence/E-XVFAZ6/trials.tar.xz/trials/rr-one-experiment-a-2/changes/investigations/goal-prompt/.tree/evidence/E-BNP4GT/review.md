# Fresh review of git diff b4f23b2 b552c30 (general-purpose subagent), findings in brief
Given: the diff, lines 1-5 verbatim, exit-code rule. Not given: the runner's Results. go test ./... passes for it.
N1 (line 1, low): a symlinked store whose target lies in another repository or outside any repository now resolves to that target: exit 3 or B's root, where before the logical path found repo A. Not probed. The exit-3 message prints the unresolved root.
N2 (line 3, low): "\r" counts as empty in an LF-only body, so "May change: a\n\r\nRead only: b\nNever: c\n" is accepted and the stray "\r" is printed. Not probed.
N3 (none, test strength): strings.Count(out, g)==5 also counts ids in block text; the symlink test does not cover a link to another repository.
Skill line: matches its claim; wording shifts from "when the Goal names one" to "when the repository keeps one".
