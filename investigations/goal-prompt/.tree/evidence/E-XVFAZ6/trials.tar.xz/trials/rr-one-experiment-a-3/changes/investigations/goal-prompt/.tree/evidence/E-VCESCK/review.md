# Fresh review of git diff b4f23b2 b87ecb0 (general-purpose subagent), findings in brief

Given: the diff, lines 1-5 as the design states them, exit codes. Not given: the runner's Results or conclusion.

Lines 1, 2, 3, 5: none.
Line 4 (low, read from code, not run): internal/cli/resolve.go:13-37 matches an alias before a display id, and the alias exactly but the id case-insensitively. A second node with alias g-abc123 makes `hyp prompt g-abc123 --actor a` resolve to that node instead of Goal G-ABC123: exit 2 if it is not a Goal, or another Goal's prompt. Only the lowercase spelling triggers it.
