# Review

Review of the candidate's diff against the Goal's lines. Finding 1: none of the changed files breaks a line; the change to the text files is what the Hypothesis states. Finding 2: no test covers the new file, which is a limit of the review and not a defect of the candidate.
