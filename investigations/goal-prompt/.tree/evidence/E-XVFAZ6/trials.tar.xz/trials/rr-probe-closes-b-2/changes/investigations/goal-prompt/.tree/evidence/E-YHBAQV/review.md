# Review of 3cfd08d (diff 2284172..3cfd08d)

Built from `git archive 3cfd08d`. `go test ./internal/cli -run Prompt -count=1` passes.
I probed the binary in a scratch store outside any repository (Goals: no block; bad block; valid block).

## Findings

1. Severity: low. Goal line: #5 and #3, but really a wording issue. The new spec sentence reads more broadly than the code.
   - Sentence: "It checks the block first, so a Goal with no valid block exits 1 wherever the store is."
   - In `cmdPrompt` the order is: argument checks (exit 2), then `openReader` (exit 3), then `resolveRef`, then the Goal-kind check (exit 2), then the block (exit 1), then symlink and repository resolution (exit 3).
   - So the block is checked before store resolution only. It is not checked first overall.
   - Probe results, all in the same store (store outside any repository; G-D53P6Z has no block):
     - `hyp prompt G-D53P6Z --actor r` gives exit 1, "no constraints block". This matches the sentence.
     - `hyp prompt G-D53P6Z` gives exit 2, "missing --actor".
     - `hyp prompt G-D53P6Z --actor BAD` gives exit 2.
     - `hyp prompt G-D53P6Z --actor r --branch 'a b'` gives exit 2.
     - `--experiments 0` and `--pr -1` also give exit 2.
     - The same no-block Goal id with a bad flag gives exit 2, not 1.
     - A DQ id (`Q-BKKQYK --actor r`) gives exit 2, "takes a Goal".
   - Outside any `.tree` store the exit is 3 ("no .tree store found"). There is no Goal to check there, so "wherever the store is" is only true when a store exists.
   - The other spec sentences already say exit 2 for these cases, so nothing contradicts. A reader taking "first" literally could expect exit 1 for a no-block Goal with a bad `--actor`.
   - Suggested wording: "It checks the block before it resolves the store's place in a repository, so a Goal with no valid block exits 1 wherever the store is."
   - Behaviour is consistent with Goal lines #3 and #5. No code change is needed.

2. Severity: low. Goal line: none (test robustness).
   - The new no-block assertion is inside `TestPromptOutsideARepository`.
   - That test calls `t.Skipf` at the top when a `.git` exists above the temp dir, so the new assertion is skipped too on such a machine.
   - On a machine whose temp dir sits under a repository, the "block checked before the repository lookup" ordering has no coverage there.
   - It does run here (`/private/var/folders`, or `/private/tmp`), and it would fail if the order were reversed: the code would return exit 3, not 1.
   - Acceptable as is.

3. Severity: info. Goal line: #3.
   - The new test covers only the "no block" case outside a repository. An invalid block outside a repository is not covered.
   - Probe: body `x\nMay change: a\nfoo` in a store outside any repository gives exit 1, listing the problems. The code path is the same, so this is behaviour-correct but not pinned by a test.

## Do the new tests test what their comments claim?

- CRLF test.
  - It checks exit 0 and `HasSuffix(stdout, "\nMay change: a.\r\nRead only: b.\r\nNever: c.\r\n")`.
  - It fails if the code trims `\r`, drops the trailing `\n` handling, or refuses CRLF.
  - The preceding "Builds.\r\n" line is correctly excluded from the block.
  - `r` is a valid actor, and a fresh Goal id is used. The test is not environment-dependent.
- No-block test.
  - It checks exit 1, empty stdout, and "no constraints block" in stderr.
  - It would fail if the repository lookup ran first (exit 3).
  - It is accurate to its comment.

No correctness bug found in the code or the tests.
