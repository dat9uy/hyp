# Plan for the /goal run (from prompt.txt and the skills only)

Sources: prompt.txt, hyp-goal-run/SKILL.md, hyp-prototype/SKILL.md, hyp-verification/SKILL.md. Nothing was run, and no file was written outside this out directory.

1. **Naming and tying each candidate commit; what a fix is.**
   - Each commit I test is one Hypothesis under the Goal's question. Its title carries the branch and the commit. The prompt names the branch feat/one-subject-per-run, and the run's PR is #132. (The current checkout is feat/goal-prompt, so I would confirm the branch before committing.)
   - Before the run, I tie the candidate's subject with `hyp subject <H> [PATH…] --base <commit> [--patch FILE]`. A Result covers a candidate only if it gave that candidate a verdict, or one of its cited runs holds the candidate's whole subject (base, patch and files).
   - A fix is a new commit and a new Hypothesis. I run `hyp add hyp` for it, then `hyp supersede <new H> --old <old H>`, then `hyp add exp` under the new H. I never edit the old Hypothesis's events.
   - I write the tree with the installed hyp. I compile the candidate to a separate path, and I never replace ~/.local/bin/hyp or the installed binary, as the prompt forbids.

2. **What each Experiment's verdict rule holds, and when I write it.**
   - The rule goes in the Experiment body, and it is written before anything runs. The recipe's checks may already exist, because `hyp add exp` pins them. No candidate runs, and no check runs on a candidate, until the rule is recorded on the Experiment. A new or changed check is first tried only on its cases' stand-ins.
   - The rule states which Goal lines the Experiment aims at (`--aims G-D1CH1R#<n>`).
   - For each new test, the rule states red on the base and green on the candidate.
   - For each refusal, the rule states a removal check: remove the refusal and show which test fails.
   - The rule states `go vet ./...` and `go test ./... -count=1`, or the repository's own gate. If no recipe pins that gate, the Experiment uses `--recipe none --rubric reading`.
   - The Goal's must-fail cases are the known-answer flaw cases, in the owner's terms.
   - If a candidate shows a check is wrong, I write the case that shows it as a new recipe version, with the outcome it must give, and I name that case in the Experiment body.
   - If a verdict rests on my reading of a Goal line, the rule names a strict check that tests the other reading. That check has its own known answers and sets no verdict.

3. **Where I keep logs.**
   - Logs go under `.tree/evidence/<E-id>/`, with short file names. Each Result cites them with `--evidence`.
   - A Result cites only files from that Experiment's own run, plus any records it pinned with `--records`.
   - The `.tree/events/` and `.tree/evidence/` files are committed with the code they describe. `.tree/index.sqlite` is never committed.

4. **What I do before the stop about a review; how I sort its findings.**
   - Before the stop, I ask a fresh subagent for one review of each candidate commit's diff. I give it the code, the Goal's lines, the settled keys and the owner's words. I do not give it my conclusion.
   - I ask it to label each finding with the line it is a case of, or with none.
   - I sort each finding into one of four kinds:
     - A case of a line is a `--limit` that I close with a Result that runs the case. If the case is void, I refer it instead.
     - A question about what a line means is a reading.
     - A defect in text I may edit is a fix commit, made before the stop.
     - Anything else is an out-of-Goal finding. It is named in the stop checkpoint, gets no limit, no refer and no reading, and never holds the select.

5. **What my last message lists for the owner.**
   - My last message repeats the stop checkpoint. The checkpoint is recorded first, with `hyp checkpoint --goal G-D1CH1R --summary "Stopped: <stop clause>. Waiting for the owner: <keys under AWAITING OWNER>. Out-of-Goal findings: <…>" --why "…"`.
   - It lists each line under LINES by its key and the Results that ran it. It names each question where OWED still owes a line. A run that ends with lines owed is a normal result, and stopping is not success.
   - It then lists every owner item with the exact command the owner runs:
     - each item under AWAITING OWNER;
     - each out-of-Goal finding, as a new Goal or an issue;
     - merging PR #132, which the runner never does;
     - reinstalling hyp;
     - each personal skill that names a command the change altered.
   - `hyp status G-D1CH1R` is printed at the end of every turn.
