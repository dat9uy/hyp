No findings. I found no input in cases 1-5 that gives a wrong outcome after this diff.

**CRLF test (G-ZBM2RE#1, tests `\r` kept in block lines): pins the behaviour.**
- I ran it. On a /tmp copy I changed the block-line write to `strings.TrimSuffix(l, "\r")`.
- `TestPromptPrintsTheGoalsRunPrompt` then failed at `prompt_test.go:77`. The stdout had lost every `\r`.
- On the unmutated code, `go test ./internal/cli -run TestPrompt -count=1` passes.

**No-block-outside-a-repository test (G-ZBM2RE#3, tests the block-first check order): pins the behaviour.**
- I ran it. On another /tmp copy I moved the `constraintsBlock` check after the `repoRoot` check.
- `TestPromptOutsideARepository` then failed at `prompt_test.go:115`. The Goal with no block exited 3 where 1 was wanted, with the "no repository holds the store" message.

**Spec edit: true of the code (read the code only).**
- "It checks the block first, so a Goal with no valid block exits 1 wherever the store is": `constraintsBlock` runs before `EvalSymlinks` and `repoRoot`.
- The CRLF sentence also matches: lines split on `\n`, and `\r` is kept in each block line.
- A lone `\r` line inside the block is a bad line, as the spec says.

**Other cases of lines 1-5 (read the code only):**
- **Line 2:** the code reads only `n.Body`.
- **Line 4:** the code reads only `n.Body`, so other Goals and answer events can't change the output.
- **Line 5:** `--actor` is checked before the store is opened, and the unknown-id and non-Goal-id checks return exit 2.

**Side note:** while I worked, an untracked directory `investigations/goal-prompt/.tree/evidence/E-2VMVJ0/` appeared in `git status`. The tests use temp dirs, so I think it came from another process, but I can't attribute it. I deleted both /tmp copies.
