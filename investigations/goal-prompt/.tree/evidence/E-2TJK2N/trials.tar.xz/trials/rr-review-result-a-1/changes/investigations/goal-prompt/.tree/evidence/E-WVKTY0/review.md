I found four defects in `843b8d6`. `go test ./internal/cli -count=1` passes, so none of them is caught by the current tests.

1. **Line 1, regression from the symlink fix.** `filepath.EvalSymlinks(r.root)` runs before `repoRoot`. Take a store at `<repo>/investigations/x`, where `x` is a symlink to a store physically outside the repository, such as `/data/x`. Before the commit, `hyp prompt` printed the path `investigations/x` and exited 0. Now it resolves to `/data/x`, finds no `.git`, and exits 3 with "no repository holds the store". A store reached through a symlink in the repository is no longer found. The commit trades one symlink failure (G1) for another, and no test covers it. The error text also names the unresolved `r.root`, so it doesn't match the path that failed. In addition, `EvalSymlinks` errors are silently ignored, so the path used can differ between runs.

2. **Line 3, a bare CR counts as empty.** `emptyLine` accepts `"\r"` in any body, not only a CRLF one. Take an LF body where one line inside the block is just `\r`, e.g. `"May change: a.\n\rRead only: b.\n..."` (a stray `\r` line). It is now accepted and printed as `"\r\n"`, though line 3 refuses any non-empty line that starts with no heading. A body is not required to be CRLF throughout. The tests cover only a fully CRLF body.

3. **Docs misstate the behaviour (`none`).**
   - `docs/replay-spec.md` §7.5 still says "A line is empty only when it holds no byte, so a line of spaces ... is a bad line". That is now false for `"\r"`.
   - The same section has no mention of the symlink resolution, and its exit-3 sentence ("when no repository holds the store") is now ambiguous about whether it uses the resolved path.
   - The repository rule is that a spec changes in the same PR as the behaviour, and this one was not updated.
   - The `constraintsBlock` doc comment now runs over one very long line, which is cosmetic.

4. **Test gap on line 1.** The symlink test links directly to the physical store directory. It does not cover a symlink to a store outside the repository (item 1), a symlink above the repository root, or an unresolvable path. The CRLF test checks only the output of one body. It does not check that `hyp add goal` warns nothing for CRLF and still warns for a bad CRLF block.

I found nothing wrong with the G8 change. `wantNamesOnly` now checks every `G-xxxxxx` id in the prompt against the expected Goal id. This is slightly weaker than before, because it no longer asserts the other Goal's id is absent. That is acceptable, since any other id fails the loop.
