---
name: transcript-score
version: 1
format: 1
subject: Count one Claude Code trial's stops from its transcript and remove's changes.json, with fingerprints the author edits; reads files only, calls no hyp
---

# transcript-score

A Standalone check that scores one trial OUT_DIR, as `hyp sandbox remove`
left it with the runner's `state.env` and `transcript.jsonl` kept. It reads
the Claude Code transcript format.

## Standalone

Run score: ./score.py
External: none

- `score OUT_DIR` prints `key<TAB>value` lines: `arm`, `trial`,
  `skill_loaded`, `tool_calls`, `failing_hyp`, one `f_<name>` per entry
  of `FINGERPRINTS`, `stops` (failing_hyp plus every fingerprint) and
  `changed`. The script's docstring defines each field. It exits 2 when
  OUT_DIR lacks `state.env`, `transcript.jsonl` or `changes.json`.
  Edit `FINGERPRINTS` for your method, and give each a case that hits it.

`known-answers/` holds a clean trial (a skill load, an error that is not a
hyp call, a hyp call that succeeds), a trial with two failing hyp calls
and a refusal, a trial with no transcript and a usage failure. Every
expected output was written by hand from the docstring.
