# Plan for the hyp-goal-run /goal prompt

Sources: the `/goal` prompt (`/tmp/g113-evals/plan/Q/prompt.txt`), `hyp-goal-run/SKILL.md`, and the two skills it names, `hyp-prototype/SKILL.md` and `hyp-verification/SKILL.md`. Nothing was run.

## 1. Naming and tying each candidate commit; what a fix is

- Each commit I test is one Hypothesis under the Goal's question (G-D1CH1R). Its title names the branch and the commit (hyp-goal-run, Build Goals).
- Before the run, I tie its subject with `hyp subject <H> --base <commit>`, adding PATH and `--patch FILE` when needed. The Goal's lines are covered only for candidates whose subject is tied (hyp-goal-run, Goal lines).
- A fix is a new commit and a new Hypothesis that supersedes the old one: `hyp supersede <new> --old <old>`. I add the new Hypothesis before its Experiment, in this order: `hyp add hyp`, then `hyp supersede`, then `hyp add exp` (hyp-prototype, Frame).
- I write the tree with the installed hyp. I compile the candidate to a separate path and never replace `~/.local/bin/hyp` or `~/.local/share/hyp/hyp-33896ec` (prompt, Never line 6).
- Commits go on `feat/one-subject-per-run`, never on main. The run may push that branch and update PR #132, but never merges it (prompt, lines 5, 9, 10; hyp-goal-run, Build Goals).

## 2. Each Experiment's verdict rule: what it holds, and when I write it

- The rule goes into the Experiment's body before anything runs. No candidate runs until the rule is recorded on the Experiment (hyp-goal-run, Work; Build Goals).
- The rule holds:
  - the Goal's lines it aims at;
  - for each new test, red on the base and green on the candidate;
  - for each refusal, a removal check: remove the refusal and show which test fails;
  - `go vet ./...` and `go test ./... -count=1`, or the repository's own gate.
- For skill text, the rule says to run the original and the candidate skills on the same eval cases (hyp-goal-run, Build Goals).
- An Experiment that runs the repository's gate on a commit uses `--recipe none --rubric reading`, with the rule in its body. A pinned recipe is used only when the Goal names one.
- A new or changed check is tried only on its cases' stand-ins, never on a candidate, until the rule is recorded. If a candidate shows a check is wrong, I write the case that shows it, in a new version, and name it in the Experiment body (hyp-goal-run, Work; hyp-verification, Find or write a recipe).
- Reassess Experiments fix their verdict rule before the run: a `rubrics/` rubric with `--rubric <name>@<version>`, or `--rubric reading` with the rule in the body (hyp-goal-run, Reassess, step 2).

## 3. Where I keep logs

- Logs go under `.tree/evidence/<E-id>/`, with short file names. Each Result cites them with `--evidence`. Observations over 600 characters go in such files, not in the observation (hyp-goal-run, Build Goals; hyp-prototype, Record; hyp-verification, Evidence).
- Evidence cited in a Result is only from this Experiment's own run, plus any records pinned with `--records` (hyp-verification, Evidence).
- Scripted evidence goes under `.tree/evidence/<E-id>/<name>` via `hyp bundle evidence --record`, and its `command.json` is cited (hyp-verification, Evidence).
- The Results are recorded with `hyp record ... --evidence .tree/evidence/<E-id>/...`. The `.tree/events/` and `.tree/evidence/` directories are committed with the code they describe (hyp-prototype, End of session).

## 4. Before the stop: the review, and how I sort its findings

- Before the stop, I ask a fresh subagent for one review of each candidate commit's diff. I give it the code, the Goal's lines, the keys already settled, and the owner's words. I do not give it my conclusion. I ask it to label each finding with the line it is a case of, or `none` (hyp-goal-run, Build Goals).
- I sort each finding (hyp-goal-run, Build Goals):
  - a case of a line becomes a `--limit` that I close, or, if the case is void, I refer it;
  - a question about what a line means becomes a reading;
  - a defect in text I may edit is fixed with a fix commit, before the stop;
  - anything else is an out-of-Goal finding. It is named in the stop checkpoint and never holds the select.

## 5. What my last message lists for the owner

- First, the stop checkpoint, recorded before the last message with `hyp checkpoint --goal G-D1CH1R --summary "Stopped: <stop clause>. Waiting for the owner: <keys under AWAITING OWNER>. Out-of-Goal findings: <one phrase each, or none>" --why "<why>"`. The stop clause is one of the prompt's three: `runner owes nothing`, five Results under claude-g1b-6, or a step I cannot take honestly, with the reason (prompt, line 2; hyp-goal-run, Stop, step 1).
- The last message repeats that checkpoint. It lists each LINES line by key with the Results that ran it, and names each question where OWED still owes a line (hyp-goal-run, Stop, step 2).
- It then lists every owner item with its exact command (hyp-goal-run, Stop, step 3):
  - each item under AWAITING OWNER;
  - each out-of-Goal finding, as a new Goal or an issue;
  - merging PR #132;
  - reinstalling hyp;
  - each personal skill that names a command the change altered.
- I print `hyp status G-D1CH1R` at the end of every turn, and name `--goal G-D1CH1R` on every `hyp checkpoint` (prompt, line 1; hyp-goal-run, Start).

## Note on the prompt

The prompt says to commit on `feat/one-subject-per-run`, but the git status at session start shows the current branch as `feat/goal-prompt`. I would confirm the branch before any commit.
