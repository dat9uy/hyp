I found no defect in 3cfd08d. The diff changes only the spec and the test file, so nothing in `prompt.go` changed.

**(a) Mutation checks, run in a detached worktree**
- **Baseline:** `go test ./internal/cli -run TestPrompt -count=1` passes on the commit.
- **CRLF test (G-ZBM2RE#1):** I changed the printing loop to `b.WriteString(strings.TrimSuffix(l, "\r"))`. `TestPromptPrintsTheGoalsRunPrompt` then fails at prompt_test.go:77, because the output lacks the `\r` before each newline. The test is red when the byte-for-byte behaviour is removed. Confirmed by running.
- **No-block-outside-a-repository test (G-ZBM2RE#3):** I moved the `constraintsBlock` refusal after the `repoRoot` and `filepath.Rel` code. `TestPromptOutsideARepository` then fails at prompt_test.go:115 with "exit 3 (want 1)". The test pins the check order. Confirmed by running.
- **Cleanup:** I removed the worktree. The repository's `git status` is unchanged, and I did not touch `~/.local/bin/hyp`.

**(b) The new spec sentence: "It checks the block first, so a Goal with no valid block exits 1 wherever the store is."**
It is true of the code for the case the commit means. After the argument and flag checks, `cmdPrompt` runs `constraintsBlock` and returns `herr.Refused` (exit 1) before `EvalSymlinks` and `repoRoot`. The test confirms it.

"Wherever the store is" is loose. Argument errors (exit 2) come first. So do `openReader` failures when no store is found, and a non-Goal id. This reads as a gap in wording, not a defect.

- **Label:** none (loosely G-ZBM2RE#3).
- **Failing input:** `hyp prompt <id> --actor A` with a bad `--branch`, or run where no store exists, on a Goal with no block.
- **Expected vs actual:** the sentence implies exit 1, but the code exits 2 or the open-store error. Confirmed by reading only. It matters only if the spec is read literally.

**(c) Other defects**
- The CRLF test uses a body with no trailing blank line, so it is valid. A CRLF body ending in a blank `\r\n\r\n` line is refused with exit 1, because the lone `\r` is a bad line. That matches the owner's answer on line 3, and the spec states it.
- The CRLF test asserts `HasSuffix` only, so it does not pin the earlier lines of the prompt. Other tests cover those.
