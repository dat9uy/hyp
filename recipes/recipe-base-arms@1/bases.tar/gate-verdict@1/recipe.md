---
name: gate-verdict
version: 1
format: 1
subject: A gate over per-trial score files: the base arm reproduces a failure at R or more of N trials, and another arm passes at P or fewer; the thresholds are arguments
---

# gate-verdict

A Standalone check that applies a reproduce-then-pass gate to the score
files of an Experiment's trials, one batched call after every trial ran.
Its thresholds are command-line arguments, so the Experiment's body
pre-registers the rule by quoting the command line.

## Standalone

Run verdict: ./verdict.py
External: none

- `verdict --field F --base ARM --trials N --repro R --pass P SCORE...`
  reads one score file per trial (`arm`, `trial` and `F`). A trial fails
  when its `F` is not 0. It prints one line per arm and `verdict:
  repro=…`, then `verdict: ARM=…` for every other arm. The script's
  docstring states the rule. It exits 2 on a usage error, a missing
  field, no base arm, or an arm without exactly N distinct trials.

`known-answers/` holds a reproducing base with a passing arm, a
reproducing base with a failing arm, a base that does not reproduce, an arm with four trials, a missing
field and a missing base arm. Every expected output was written by hand
from the docstring.
