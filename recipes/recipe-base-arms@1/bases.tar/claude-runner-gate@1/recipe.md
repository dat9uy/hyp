---
name: claude-runner-gate
version: 1
format: 1
subject: One Claude Code runner (claude -p) per sandbox trial, its stops scored from its transcript and changes, and a reproduce-then-pass gate over every trial's score
---

# claude-runner-gate

A whole runner gate in one bundle. One sandbox per trial: Launch gives a
fresh Claude Code runner a brief and a method, Drive runs it and keeps its
transcript, `score` counts the trial's stops, and `verdict` applies a gate
to every trial's score in one batched call. It drives `claude -p` only; a
runner for another harness is another base. Create each sandbox with
`--inputs FILE`, and with `--store SRC --cut EVENT` when the runner starts
from a tree at a store cut; `--hyp BIN` pins the hyp the runner calls.

## Launch

Run: ./launch.sh

Reads the inputs file, `KEY=VALUE` lines `arm`, `trial` and `model`, and
exits 2 when one is missing. It copies the inputs to this recipe's tmp as
`state.env`, deletes the paths in `STRIP` from `wt/`, copies the two hyp
skills into `wt/.claude/skills/`, and writes `brief.txt` followed by
`method.md` to this recipe's tmp as the runner's brief. Edit `STRIP`,
`brief.txt` and `method.md` for your method.

## Doctor

Run: ./doctor.sh

Passes when `claude`, `python3` and the pinned `hyp` run, the stripped
paths are gone, `.claude/` holds only `skills/` and the brief exists.

## Drive

Run: ./drive.py

Runs `claude -p --model MODEL --setting-sources project --permission-mode
dontAsk --allowedTools Bash Read Edit Write Glob Grep Skill` in `wt/` with
the brief on stdin, without `HYP_*` or `CLAUDE_CODE_*` variables and with
`HYP_ACTOR=runner-<arm>-<trial>`, and stops it after 50 minutes. It copies
the session transcript to this recipe's tmp as `transcript.jsonl` and
writes `drive.json` (arm, trial, model, exit, turns, cost_usd, denials).
It exits 1 when no transcript was written.

## Evidence

Kept by hand at remove: `--keep tmp/<name>/state.env --keep
tmp/<name>/drive.json --keep tmp/<name>/transcript.jsonl`, with `<name>`
this bundle's name. What the runner changed reaches OUT_DIR through
`changes/` and `changes.json`. Then `score` runs on that OUT_DIR, as a
Standalone command, once per trial, and `verdict` once over all of them.

## Cleanup

Run: ./cleanup.sh

Nothing is left running: Drive waits for the runner to end.

## Standalone

Run score: ./score.py
External: none

Run verdict: ./verdict.py
External: none

- `score OUT_DIR` prints `key<TAB>value` lines: `arm`, `trial`, `model`
  and `cost_usd` (from Drive's `drive.json`), `skill_loaded`,
  `tool_calls`, `failing_hyp`, one `f_<name>` per entry of
  `FINGERPRINTS`, `stops` (failing_hyp plus every fingerprint) and
  `changed`. The script's docstring defines each field. It exits 2 when
  OUT_DIR lacks `state.env`, `drive.json`, `transcript.jsonl` or
  `changes.json`. Edit `FINGERPRINTS` for your method, and give each a
  case that hits it.
- `verdict --field F --base ARM --trials N --repro R --pass P SCORE...`
  reads one score file per trial. A trial fails when its `F` is not 0. It
  prints one line per arm and `verdict: repro=…`, then `verdict: ARM=…`
  for every other arm. The script's docstring states the rule. It exits 2
  on a usage error, a missing field, no base arm, or an arm without
  exactly N distinct trials.

`known-answers/` holds, for `score`, a clean trial, a trial with two
failing hyp calls and a refusal, a trial with no transcript, a usage
failure, and `score-seam`, whose `drive.json` is what `drive.py` wrote
when run on a stub `claude`, so a change to Drive's output that score
cannot read fails the gate; and, for `verdict`, a reproducing base with a
passing arm, a reproducing base with a failing arm, a base that does not reproduce, an arm with
four trials, a missing field and a missing base arm. Every other expected
output was written by hand from the docstrings.
