#!/usr/bin/env python3
"""verdict --field F --base ARM --trials N --repro R --pass P SCORE...: a gate over score outputs.

Each SCORE is a file of key<TAB>value lines for one trial, with at least
arm, trial and F. F is a failure field: a trial fails when its F is not 0.
Every arm must have exactly N trials with distinct trial values.

For each arm, k is its number of failing trials. The base arm (the one
without the change) reproduces the failure when its k >= R. Any other arm
passes when its k <= P.

  verdict: repro=supports        when base reproduces
  verdict: repro=contradicts     when it does not
  verdict: ARM=supports          for an arm with k <= P, when base reproduces
  verdict: ARM=contradicts       for an arm with k > P, when base reproduces
  verdict: ARM=inconclusive      for every other arm, when base does not

Prints one line per arm (sorted, base first), then the verdict lines.
Exits 2 on a usage error, an unreadable file, a missing field, a value of F
that is not a number, no base arm, or an arm without exactly N distinct
trials. The thresholds are arguments, so a pre-registered rule is the
command line that runs this script.
"""
import argparse
import sys


class Parser(argparse.ArgumentParser):
    def error(self, message):
        fail(message)


def fail(msg):
    print("verdict: " + msg, file=sys.stderr)
    sys.exit(2)


def main():
    ap = Parser(add_help=False)
    for flag in ("--field", "--base"):
        ap.add_argument(flag, required=True)
    for flag in ("--trials", "--repro", "--pass"):
        ap.add_argument(flag, required=True, type=int)
    ap.add_argument("scores", nargs="+")
    a = ap.parse_args()
    arms = {}
    for p in a.scores:
        try:
            kv = dict(l.rstrip("\n").split("\t", 1) for l in open(p) if "\t" in l)
        except OSError as e:
            fail(f"cannot read {p}: {e}")
        for k in ("arm", "trial", a.field):
            if k not in kv:
                fail(f"{p} has no {k}")
        try:
            failed = float(kv[a.field]) != 0
        except ValueError:
            fail(f"{p}: {a.field} is {kv[a.field]!r}, not a number")
        arms.setdefault(kv["arm"], {})
        if kv["trial"] in arms[kv["arm"]]:
            fail(f"arm {kv['arm']} has trial {kv['trial']} twice")
        arms[kv["arm"]][kv["trial"]] = failed
    if a.base not in arms:
        fail(f"no trial of the base arm {a.base}")
    for arm, t in arms.items():
        if len(t) != a.trials:
            fail(f"arm {arm} has {len(t)} trials, want {a.trials}")
    k = {arm: sum(t.values()) for arm, t in arms.items()}
    order = [a.base] + sorted(x for x in arms if x != a.base)
    for arm in order:
        print(f"{arm}: {a.field} failing {k[arm]} of {a.trials}")
    repro = k[a.base] >= a.repro
    print(f"verdict: repro={'supports' if repro else 'contradicts'}")
    for arm in order[1:]:
        word = ("supports" if k[arm] <= getattr(a, "pass") else "contradicts") if repro else "inconclusive"
        print(f"verdict: {arm}={word}")


if __name__ == "__main__":
    main()
