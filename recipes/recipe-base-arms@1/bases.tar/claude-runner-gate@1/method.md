# Method

Replace this file with the pre-registered method the runner follows. Launch
gives it to the runner after `brief.txt`, on stdin only.
