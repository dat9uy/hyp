# Fresh review of git diff b4f23b2 4e3fba5 (general-purpose subagent), findings in brief

Given: the diff, lines 1-5 of G-ZBM2RE, the claimed fixes G1, G2, G5-G8, AGENTS.md. Not given: the runner's Results or conclusions.

Checked correct: G2 (CRLF test fails on old code, passes now; block lines keep "\r\n"); G1 (symlink test fails on old code); G7 (skips when a directory above TMPDIR holds .git); G8 (wantNamesOnlyAll needs five ids, all the Goal's); G5/G6 wording matches code and spec. No defect on lines 2 to 5.

F1 (line 1, low) prompt.go:151-158: EvalSymlinks of the store root changes the printed path for any symlink. A store that is a symlink to a directory outside the repository exits 3; R/link -> R/real/tree prints "real/tree", not "link". The exit-3 message shows the unresolved r.root.
