# Handoff: next /goal prompt for G-D1CH1R

Source: /tmp/g113-evals/exit/Q/skills/hyp-owner-answer/SKILL.md (read only; no commands run).

## (1) Command

The skill's last section gives the form `hyp prompt <goal> --actor <new runner actor> [--branch <branch>] [--pr <N>]`. With the values given:

```text
hyp prompt G-D1CH1R --actor claude-g1b-7 --branch feat/x --pr 9
```

Give the owner its output as it is. Do not add the owner's answers to it. OWED lists each answer and each returned limit that the next run applies.

The skill says to print this prompt only when the owner's answers leave work for the runner. It does not say how to check that. I answer from the skill only, so I have not checked it.

## (2) If the command exits 3

Exit 3 is an environment problem, such as a busy port or a missing tool (AGENTS.md, and sandbox-spec.md §1.3 as cited there). The skill does not name a step for exit 3 of `hyp prompt`. So I do not invent one. I would:

- Report the exit code and the error text to the owner.
- Not give the owner a prompt, because none was printed.
- Not change the tree. The Goal and its readings stay as they are.
- Run the same command again after the environment problem is fixed.

## (3) If the command exits 1

Exit 1 is a rule refusal (AGENTS.md; sandbox-spec.md §1.3). The skill does not name a step for exit 1 of `hyp prompt` either. So I would:

- Show the owner the refusal text in full.
- Not give the owner a prompt, and not work around the refusal.
- Not edit the tree or any event to clear it. The owner decides what the refusal means for the Goal.

## (4) What I add to the prompt about the owner's answers

Nothing. The skill says not to add the owner's answers to the `hyp prompt` output. OWED already lists each answer and each returned limit that the next run applies. I give the output to the owner unchanged.
