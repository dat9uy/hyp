# Review of 686373d (docs/replay-spec.md section 7.5, one sentence)

Built from `git archive 686373d` into /private/tmp/claude-501/b686. The repo was not touched.

## Verdict
The new sentence is true of internal/cli/prompt.go in every case I probed. The order in code is:
1. flag parse and positional count (exit 2)
2. --actor missing, invalid actor, --experiments < 1, --pr < 0, --branch with space or control character (exit 2)
3. openReader (no store found or unreadable, exit 3)
4. resolveRef: unknown id (exit 2)
5. non-Goal (exit 2)
6. block check (exit 1)
7. EvalSymlinks failure (exit 3)
8. no repository holds the store (exit 3)

## Probes
All probes ran with a no-block Goal (NB) or a valid-block Goal (OK). Every result matched the spec.

| Store | Input | Exit | Stdout |
|---|---|---|---|
| inside repo | NB --actor a | 1, "refused: ... no constraints block" | empty |
| inside repo | OK --actor a | 0 | prompt |
| outside every repo | NB --actor a | 1 | empty |
| outside every repo | OK --actor a | 3, "no repository holds the store" | empty |
| outside, linked from a repo | NB --actor a | 1 | empty |
| outside, linked from a repo | OK --actor a | 3 | empty |
| inside repo | NB, no --actor | 2 "missing --actor" | empty |
| outside every repo | NB, no --actor | 2 "missing --actor" | empty |
| no .tree anywhere | NB, no --actor | 2 | empty |
| outside every repo | NB --actor a --branch "b b" | 2 | empty |
| outside every repo | NB --actor a --branch with a tab | 2 | empty |
| outside every repo | NB --actor a --experiments 0 | 2 | empty |
| outside every repo | NB --actor a --pr -1 | 2 | empty |
| outside every repo | NB --actor BAD | 2 | empty |
| outside every repo | NB extra --actor a (extra positional) | 2 | empty |
| outside every repo | `G-NOPE --actor a` (unknown id) | 2 "unknown node G-NOPE" | empty |
| inside repo | `Q-7BP6EM --actor a` (a DQ) | 2 "takes a Goal" | empty |
| store directory moved away from the cwd | OK --actor a | 3 "no repository holds the store" | empty |

Flag errors and a missing --actor win over the block, as the new clause says. Unknown and non-Goal ids exit 2 before the block, as the new clause says. The block check wins over the repository lookup in both the outside-store and linked-store cases.

## Findings

1. Minor spec gap, no code bug. Goal line: #3, which says exit 1 when the block is missing, so "wherever the store is" can mislead.
   - A store that cannot be opened exits 3 before the block check, even for a no-block Goal.
   - Input: `chmod 000 .tree/events/a.jsonl; hyp prompt <NB> --actor a`. Observed exit 3 with stderr `open .../a.jsonl: permission denied`.
   - Input: a cwd with no `.tree` and `hyp prompt <NB> --actor a`. Observed exit 3 with stderr `no .tree store found; run 'hyp init'`.
   - The paragraph's exit-3 list names only "the store's directory cannot be resolved or no repository holds its real directory". It does not list "no store found or unreadable", which comes before the block check.
   - The new sentence says only that the argument checks and the Goal check come before the block. It leaves out that opening the store (exit 3) comes first as well.
   - "Wherever the store is" reads fine as a statement about where the store sits. It does not mean "whatever state the store is in".
   - Suggested wording: add "a store that cannot be found or read exits 3 before the block is checked".
   - Corrupt event lines do not cause this. A garbage line appended to an event file was tolerated, and the no-block Goal still exited 1.

No other findings. The ordering claims in the new sentence match the code.
