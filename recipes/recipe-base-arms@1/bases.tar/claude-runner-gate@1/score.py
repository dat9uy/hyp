#!/usr/bin/env python3
"""score OUT_DIR: one trial's stops, read from its transcript and changes.

OUT_DIR is hyp sandbox remove's, with state.env, drive.json and
transcript.jsonl kept from this recipe's tmp (Drive writes the last two),
and changes.json written by remove. Prints key<TAB>value lines:

  arm, trial      from state.env
  model, cost_usd from drive.json, as Drive wrote them
  skill_loaded    1 when the runner made a Skill call or a Read of a file
                  named SKILL.md
  tool_calls      every tool call the runner made
  failing_hyp     Bash calls that end in error with hyp as their last command
                  (the one whose exit status the call returns, heredoc
                  bodies dropped)
  f_<name>        1 when a FINGERPRINTS entry matches, else 0
  stops           failing_hyp plus every f_ value
  changed         paths remove lists as added or modified

A fingerprint is (name, where, pattern): where is "error" (the text of an
errored tool result), "bash" (a Bash command) or "path" (a changed path).
Edit FINGERPRINTS for your method; each one needs a known-answer case that
hits it. This script reads files only and calls no hyp. Exits 2 when OUT_DIR
lacks state.env, drive.json, transcript.jsonl or changes.json, and 0
otherwise.
"""
import json
import os
import re
import sys

FINGERPRINTS = [
    ("refused", "error", r"^refused: "),
]

LAST_HYP = re.compile(r"^(\w+=\S*\s+)*(\S*/)?hyp\s+[a-z-]")
HEREDOC = re.compile(r"<<-?\s*['\"]?(\w+)['\"]?[^\n]*\n.*?\n\s*\1\s*(?=\n|$)", re.S)


def last_command(cmd):
    """The command whose exit status a Bash call returns: heredoc bodies dropped, then
    the last part after a newline, ;, && or ||, and after its last |."""
    parts = [p.strip() for p in re.split(r"\n|;|&&|\|\|", HEREDOC.sub("", cmd)) if p.strip()]
    return parts[-1].split("|")[-1].strip() if parts else ""


def fail(msg):
    print("score: " + msg, file=sys.stderr)
    sys.exit(2)


def blocks(lines, kind, role):
    for l in lines:
        content = (l.get("message") or {}).get("content")
        if l.get("type") == role and isinstance(content, list):
            for b in content:
                if isinstance(b, dict) and b.get("type") == kind:
                    yield b


def text_of(block):
    c = block.get("content")
    if isinstance(c, list):
        return "\n".join(x.get("text", "") for x in c if isinstance(x, dict))
    return c if isinstance(c, str) else ""


def main():
    if len(sys.argv) != 2:
        fail("usage: score OUT_DIR")
    out = sys.argv[1]
    for f in ("state.env", "drive.json", "transcript.jsonl", "changes.json"):
        if not os.path.isfile(os.path.join(out, f)):
            fail(f"{out} holds no {f}")
    st = dict(l.rstrip("\n").split("=", 1) for l in open(os.path.join(out, "state.env")) if "=" in l)
    with open(os.path.join(out, "transcript.jsonl")) as f:
        lines = [json.loads(l) for l in f if l.strip()]
    drive = json.load(open(os.path.join(out, "drive.json")))
    changes = json.load(open(os.path.join(out, "changes.json")))["changes"]
    live = [c["path"] for c in changes if c.get("change") in ("added", "modified")]

    errors = {}
    for b in blocks(lines, "tool_result", "user"):
        if b.get("is_error"):
            errors[b.get("tool_use_id")] = text_of(b)
    seen, failing, calls, loaded, bash = set(), 0, 0, 0, []
    for b in blocks(lines, "tool_use", "assistant"):
        if b.get("id") in seen:
            continue
        seen.add(b.get("id"))
        calls += 1
        inp = b.get("input") or {}
        if b.get("name") == "Skill" or (b.get("name") == "Read" and os.path.basename(inp.get("file_path", "")) == "SKILL.md"):
            loaded = 1
        if b.get("name") == "Bash":
            cmd = inp.get("command", "")
            bash.append(cmd)
            if LAST_HYP.match(last_command(cmd)) and b.get("id") in errors:
                failing += 1
    where = {"error": list(errors.values()), "bash": bash, "path": live}
    rows = [("arm", st.get("arm", "")), ("trial", st.get("trial", "")), ("model", drive.get("model")),
            ("cost_usd", drive.get("cost_usd")), ("skill_loaded", loaded),
            ("tool_calls", calls), ("failing_hyp", failing)]
    stops = failing
    for name, w, pat in FINGERPRINTS:
        hit = int(any(re.search(pat, t, re.M) for t in where[w]))
        rows.append(("f_" + name, hit))
        stops += hit
    rows += [("stops", stops), ("changed", len(live))]
    for k, v in rows:
        print(f"{k}\t{v}")


if __name__ == "__main__":
    main()
