# Review of 3cfd08d (hyp prompt)

Ran: go vet ./... (clean), go test ./... -count=1 (all ok, incl. skillcheck), and probes with a binary built from a detached worktree in a scratch git repo.

No defect found against G-ZBM2RE#1..#7, the design, docs/replay-spec.md, or the skill text.

Probes that matched the Goal lines and the spec:
- #3: a body with no heading, a heading-only body, and a trailing foreign line all exit 1 with empty stdout. Each names its missing headings or the bad line. `hyp add goal` exits 0 and warns for a body with a heading but no valid block, and is silent when there is no heading.
- #3: interior and trailing blank lines are accepted. Interior ones print; trailing ones are trimmed.
- #5: no --actor exits 2 even with HYP_ACTOR set. Unknown id, non-Goal id (a DQ), a short id without its prefix, a bad actor, --pr -1, a branch holding NBSP, and a stray extra positional all exit 2.
- #1/#4: output is stable across calls. Store path and flags print as the spec says.
- Exit 3: a store outside every repository exits 3, also when reached through a symlink.
- Stop-clause text matches internal/render/status.go:361. The skill-text flags (hyp subject --base, hyp supersede --old, --recipe none --rubric reading, hyp checkpoint --goal) exist in the binary.

Observations, none of them contradicting a line, the design or the spec (label: none, not defects):
1. A store at the repository root prints "Run the hyp tree in . with ...". It is correct by the spec ("path relative to the repository root") but reads oddly. Confirmed: `hyp prompt a --actor run-1` in a repo with `.tree` at its root.
2. `--pr 0` is silently ignored (no clause printed) instead of exiting 2, while `--pr -1` exits 2. Confirmed. The spec does not list it.
3. The spec's exit-2 list names no-actor, non-Goal and a bad --branch. It omits an invalid actor name, --experiments < 1 and --pr < 0, which the binary also refuses with exit 2. This is an incompleteness, not a contradiction. Confirmed with --actor Bad_Actor and --pr -1.
