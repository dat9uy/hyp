I found no defects in `3cfd08d` or in the feature as a whole. This is from reading the code, docs and skills; I did not run the tests or the binary.

Checked against the Goal's lines:

- **#1:** `cmdPrompt` (`internal/cli/prompt.go:119-176`) builds its output from the Goal node's body, the real path of the store relative to the repository root, the actor, and the flags. The block lines are copied unchanged in body order, with only trailing empty lines dropped. `--branch` and `--pr` add their clauses after the block. Nothing varies between calls.
- **#2 and #4:** The command reads only `n.Body`, the node kind and the store location. It never reads answers or other Goals. The `n.Kind` and `n.Body` reads, `resolveRef` and `constraintsBlock` use only that one node.
- **#3:** `constraintsBlock` (`internal/cli/prompt.go:28-64`) starts the block at the first heading line, treats only a zero-byte line as empty, and reports each bad line and each missing heading. It returns exit 1 before any stdout. `hyp add goal` still exits 0 and warns through `blockWarning` (`internal/cli/write.go:395`), only when a heading exists but the block is invalid. A lone `\r` line is refused, which the owner allowed.
- **#5:** A missing `--actor` exits 2, `$HYP_ACTOR` is never read, and an unknown, ambiguous or non-Goal id exits 2.
- **#6 and #7 (skill text):** The `skills/` edits match the code and docs. The stop string in the prompt matches `internal/render/status.go:361`. `hyp checkpoint --goal` exists. The exit codes the skills describe match the command.

Two points that are not defects:

- **Spec text (`docs/replay-spec.md:235`):** The exit-2 list does not mention `--experiments < 1` or `--pr < 0`, which the code also refuses with exit 2. This is only an omission in the text and breaks no line.
- **Outside this change:** `skills/hyp-owner-answer/SKILL.md:136` and `skills/hyp-prototype/SKILL.md:203` show `hyp checkpoint` without `--goal`, which a multi-Goal store requires. This existed before the change, is not in the diff, and is not a case of any line (none).
