# Review of 3cfd08d (docs/replay-spec.md paragraph, internal/cli/prompt_test.go)

Method: ran `go test ./internal/cli -run Prompt` on a detached worktree of 3cfd08d (passes), then applied mutations to internal/cli/prompt.go one at a time. The worktree is removed.

## Truth of the additions against prompt.go

- **Block checked before the repository (#3, #1).** The sentence "It checks the block first, so a Goal with no valid block exits 1 wherever the store is" is true of prompt.go:145-148 against 151-158. The check comes after the exit-2 checks, `openReader` and `resolveRef`. So "wherever the store is" holds only for a store hyp can open, and the spec's own exit-2 list still wins first. This is a wording imprecision, not a bug. No failing input found that contradicts a goal line.
- **CRLF paragraph (#3, owner answer).** "A lone `\r` of a blank line in a CRLF body is a bad line" is true: prompt.go:31 splits on `\n` only and prompt.go:48 skips only `""`. "A CRLF body with no blank line in its block keeps the `\r` at the end of each block line" is true: prompt.go:169-170 writes `l` unchanged. This fits the owner's answer "CRLF bodies need not be accepted" and goal #1 "byte for byte".
- **New CRLF test (prompt_test.go:73-78, case of #1).** It passes. Its `HasSuffix` check is correct only because no `--branch` or `--pr` is given, so the block ends the output. A `--branch` run would put the clause after the block, which is a different assertion, and nothing is wrong there.
- **New no-block test (prompt_test.go:111-116, case of #3).** It passes and is true of the code.

## Mutation results

| Mutation | New test goes red? |
|---|---|
| Strip `\r` when printing a block line (`TrimRight(l,"\r")`) | Yes, CRLF test (prompt_test.go:77). |
| Move the block check after the `repoRoot` / `EvalSymlinks` step | Yes, outside-repo test (prompt_test.go:115 reports exit 3, want 1). |
| Normalize `\r\n` to `\n` before splitting | Yes, CRLF test fails. The older blank-CRLF-line case at prompt_test.go:219 also fails. |
| Treat whitespace-only lines as empty (`TrimSpace(l)==""`) | Caught by the existing test at prompt_test.go:219, not by the new ones. |

Both new tests are red under their intended mutation.

## Findings

1. **Surviving mutation, an indented heading counts as a heading (#3, pre-existing, not in this diff).** Mutation: `headingOf` uses `HasPrefix(TrimSpace(line), h)`. All Prompt tests still pass. The spec says "starts with". Input: body `"  May change: x\nRead only: y\nNever: z"`. Correct behavior: the block starts at line 2, there is no `May change:` heading, so exit 1. Under the mutation it would be accepted. No test covers leading whitespace before a heading.
2. **Surviving mutation, trailing whitespace-only lines are trimmed from the block (#3, pre-existing).** Mutation: the trailing-trim loop at prompt.go:43 uses `TrimSpace(...)==""`. All tests pass. The new spec sentence says "a line of spaces ... is a bad line inside the block". Input: `"May change: a\nRead only: b\nNever: c\n   "`, or the same body ending in `\r`. Correct behavior is exit 1. The mutation accepts it. The tests cover bad lines only in the middle of the block, so a bad final line is untested. The CRLF test in this diff has a trailing `\r\n`, which leaves the last element `""`, so it does not touch this case. A body ending in a lone `\r` with no newline, such as `"...Never: c.\r"`, is a legitimate last line that prints with `\r`. It is untested.
3. **Wording (none).** "wherever the store is" is stronger than the code gives (see above). "wherever the store is placed in or out of a repository" would be exact.

No contradiction between the spec sentences and prompt.go was found. No failing input was found for goals #2, #4 or #5 in this diff, which does not touch them.
