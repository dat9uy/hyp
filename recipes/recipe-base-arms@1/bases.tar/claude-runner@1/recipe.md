---
name: claude-runner
version: 1
format: 1
subject: One Claude Code runner (claude -p) per sandbox, given a brief and a method on stdin, its transcript and a drive.json kept for remove
---

# claude-runner

A sandbox's Launch, Doctor, Drive and Cleanup for one trial of a fresh
Claude Code runner. It drives `claude -p` only; a runner for another
harness is another base. Create the sandbox with `--inputs FILE`, and
with `--store SRC --cut EVENT` when the runner starts from a tree at a
store cut; `--hyp BIN` pins the hyp the runner calls.

## Launch

Run: ./launch.sh

Reads the inputs file, `KEY=VALUE` lines `arm`, `trial` and `model`, and
exits 2 when one is missing. It copies the inputs to this recipe's tmp as
`state.env`, deletes the paths in `STRIP` from `wt/`, copies the two hyp
skills into `wt/.claude/skills/`, and writes `brief.txt` followed by
`method.md` to this recipe's tmp as the runner's brief. Edit `STRIP`,
`brief.txt` and `method.md` for your method.

## Doctor

Run: ./doctor.sh

Passes when `claude`, `python3` and the pinned `hyp` run, the stripped
paths are gone, `.claude/` holds only `skills/` and the brief exists.

## Drive

Run: ./drive.py

Runs `claude -p --model MODEL --setting-sources project --permission-mode
dontAsk --allowedTools Bash Read Edit Write Glob Grep Skill` in `wt/` with
the brief on stdin, without `HYP_*` or `CLAUDE_CODE_*` variables and with
`HYP_ACTOR=runner-<arm>-<trial>`, and stops it after 50 minutes. It copies
the session transcript to this recipe's tmp as `transcript.jsonl` and
writes `drive.json` (arm, trial, model, exit, turns, cost_usd, denials).
It exits 1 when no transcript was written.

## Evidence

Kept by hand at remove: `--keep tmp/<name>/state.env --keep
tmp/<name>/drive.json --keep tmp/<name>/transcript.jsonl`, with `<name>`
this bundle's name. What the runner changed reaches OUT_DIR through
`changes/` and `changes.json`.

## Cleanup

Run: ./cleanup.sh

Nothing is left running: Drive waits for the runner to end.
